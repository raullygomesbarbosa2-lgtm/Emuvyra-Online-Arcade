# NEON//VERSUS — Cloudflare Workers MVP

Protótipo web sem CHIP-8. Usa Workers para servir a página e Durable Objects com WebSockets para salas em tempo real e matchmaking básico. Não inclui jogos, ROMs ou BIOS e ainda não implementa emulação nem rollback netcode.

## Conta e custo

A publicação usa uma conta Cloudflare e o plano gratuito. O plano tem limites de uso que podem mudar; exceder os limites pode interromper operações. Confira os limites atuais antes de publicar e monitore o painel da conta. Este projeto não configura pagamentos nem escolhe um plano pago.

## Requisitos

- Node.js 20 ou superior e npm
- Conta Cloudflare
- Acesso ao terminal

Não precisa criar ou conectar um repositório GitHub: o Wrangler envia os arquivos locais para a Cloudflare.

## Rodar localmente

```bash
npm install
npx wrangler dev
```

O Wrangler mostra o endereço local. Abra-o em dois navegadores para testar criação de sala, entrada por código e matchmaking.

## Publicar na Cloudflare

```bash
npx wrangler login
npx wrangler deploy
```

O comando de login abre a autorização da Cloudflare no navegador. O deploy usa a configuração deste projeto e solicita as permissões necessárias para criar o Worker e o Durable Object. Revise o plano e as cotas na conta antes de publicar.

## Rotas

- `/` — interface do app
- `/api/health` — verificação simples do Worker
- `/ws` — conexão WebSocket usada pelas salas e pela fila

## Próximas etapas

1. Criar salas com senha/convites e controles de abuso.
2. Adicionar autenticação de jogadores e persistência se necessário.
3. Integrar emulador compatível e com licença adequada.
4. Implementar netcode rollback e validar latência.

O matchmaking atual serve como base de demonstração; não sincroniza estado de jogo nem executa partidas em si.

const MAX_NAME_LENGTH = 20;
const MAX_ROOM_PLAYERS = 2;
const VALID_GAMES = new Set(['sf3', 'kof2002', 'garou']);

export class Lobby {
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
  }

  async fetch(request) {
    if (request.headers.get('Upgrade')?.toLowerCase() !== 'websocket') {
      return new Response('WebSocket upgrade required', { status: 426 });
    }

    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({
      id: crypto.randomUUID(),
      playerName: 'Player',
      gameId: null,
      roomCode: null,
      queueGame: null,
    });

    return new Response(null, { status: 101, webSocket: client });
  }

  webSocketMessage(socket, rawMessage) {
    let message;
    try {
      const text = typeof rawMessage === 'string'
        ? rawMessage
        : new TextDecoder().decode(rawMessage);
      message = JSON.parse(text);
    } catch {
      this.send(socket, { type: 'app:error', message: 'Mensagem inválida.' });
      return;
    }

    const current = this.attachment(socket);
    const name = this.cleanName(message.playerName || current.playerName);

    switch (message.type) {
      case 'hello': {
        this.save(socket, { ...current, playerName: name });
        this.send(socket, { type: 'hello:ok' });
        this.broadcastRooms();
        break;
      }
      case 'room:create':
        this.createRoom(socket, current, message, name);
        break;
      case 'room:join':
        this.joinRoom(socket, current, message, name);
        break;
      case 'match:queue':
        this.joinQueue(socket, current, message, name);
        break;
      default:
        this.send(socket, { type: 'app:error', message: 'Ação desconhecida.' });
    }
  }

  webSocketClose(socket) {
    this.removeFromQueue(socket);
    this.broadcastRooms();
  }

  webSocketError(socket) {
    this.removeFromQueue(socket);
    this.broadcastRooms();
  }

  createRoom(socket, current, message, playerName) {
    const gameId = this.cleanGame(message.gameId);
    if (!gameId) return this.send(socket, { type: 'app:error', message: 'Escolha um jogo válido.' });
    if (current.roomCode) return this.send(socket, { type: 'app:error', message: 'Você já está em uma sala.' });

    this.removeFromQueue(socket);
    const code = this.newCode();
    const updated = { ...this.attachment(socket), playerName, gameId, roomCode: code, queueGame: null };
    this.save(socket, updated);
    this.send(socket, { type: 'room:created', room: { code, gameId, host: playerName, players: 1 } });
    this.broadcastRooms();
  }

  joinRoom(socket, current, message, playerName) {
    const code = String(message.code || '').trim().toUpperCase();
    const connections = this.connections();
    const group = connections.filter(entry => entry.data.roomCode === code);
    if (group.length === 0) return this.send(socket, { type: 'app:error', message: 'Essa sala não existe mais.' });
    if (group.length >= MAX_ROOM_PLAYERS) return this.send(socket, { type: 'app:error', message: 'Essa sala já está cheia.' });
    if (current.roomCode) return this.send(socket, { type: 'app:error', message: 'Você já está em uma sala.' });

    this.removeFromQueue(socket);
    const gameId = group[0].data.gameId;
    this.save(socket, { ...this.attachment(socket), playerName, gameId, roomCode: code, queueGame: null });
    const room = { code, gameId, host: group[0].data.playerName, players: group.length + 1 };
    this.send(socket, { type: 'room:joined', room });
    for (const entry of group) this.send(entry.socket, { type: 'room:ready', room });
    this.broadcastRooms();
  }

  joinQueue(socket, current, message, playerName) {
    const gameId = this.cleanGame(message.gameId);
    if (!gameId) return this.send(socket, { type: 'app:error', message: 'Escolha um jogo válido.' });
    if (current.roomCode) return this.send(socket, { type: 'app:error', message: 'Saia da sala atual antes de buscar outra partida.' });

    const peers = this.connections().filter(entry =>
      entry.socket !== socket && entry.data.queueGame === gameId && !entry.data.roomCode
    );

    this.removeFromQueue(socket);
    if (peers.length) {
      const opponent = peers[0];
      const code = this.newCode();
      const room = {
        code,
        gameId,
        host: opponent.data.playerName,
        players: MAX_ROOM_PLAYERS,
      };
      this.save(opponent.socket, { ...opponent.data, roomCode: code, queueGame: null, gameId });
      this.save(socket, { ...this.attachment(socket), playerName, roomCode: code, queueGame: null, gameId });
      this.send(opponent.socket, { type: 'match:found', room });
      this.send(socket, { type: 'match:found', room });
      this.broadcastRooms();
      return;
    }

    this.save(socket, { ...this.attachment(socket), playerName, gameId, queueGame: gameId, roomCode: null });
    this.send(socket, { type: 'match:queued', gameId });
  }

  connections() {
    return this.ctx.getWebSockets().map(socket => ({ socket, data: this.attachment(socket) }));
  }

  broadcastRooms() {
    const groups = new Map();
    for (const entry of this.connections()) {
      const data = entry.data;
      if (!data.roomCode) continue;
      const existing = groups.get(data.roomCode);
      if (existing) existing.players += 1;
      else groups.set(data.roomCode, {
        code: data.roomCode,
        gameId: data.gameId,
        host: data.playerName,
        players: 1,
      });
    }

    const rooms = [...groups.values()].filter(room => room.players < MAX_ROOM_PLAYERS);
    this.broadcast({ type: 'rooms:update', rooms });
  }

  broadcast(payload) {
    for (const { socket } of this.connections()) this.send(socket, payload);
  }

  removeFromQueue(socket) {
    const data = this.attachment(socket);
    if (data.queueGame) this.save(socket, { ...data, queueGame: null });
  }

  attachment(socket) {
    try {
      return socket.deserializeAttachment() || {};
    } catch {
      return {};
    }
  }

  save(socket, data) {
    socket.serializeAttachment(data);
  }

  send(socket, payload) {
    try {
      socket.send(JSON.stringify(payload));
    } catch {
      // A closed connection is removed by the WebSocket lifecycle callback.
    }
  }

  cleanName(value) {
    const name = String(value || 'Player').trim().slice(0, MAX_NAME_LENGTH);
    return name || 'Player';
  }

  cleanGame(value) {
    const gameId = String(value || '');
    return VALID_GAMES.has(gameId) ? gameId : null;
  }

  newCode() {
    return crypto.randomUUID().replaceAll('-', '').slice(0, 5).toUpperCase();
  }
}

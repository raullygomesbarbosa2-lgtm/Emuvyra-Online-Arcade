export { Lobby } from './lobby.js';

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === '/api/health') {
      return Response.json({ ok: true, service: 'neon-versus-cloudflare' });
    }

    if (url.pathname === '/ws') {
      if (request.headers.get('Upgrade')?.toLowerCase() !== 'websocket') {
        return new Response('WebSocket upgrade required', { status: 426 });
      }
      const id = env.LOBBY.idFromName('global-lobby');
      return env.LOBBY.get(id).fetch(request);
    }

    return env.ASSETS.fetch(request);
  },
};
